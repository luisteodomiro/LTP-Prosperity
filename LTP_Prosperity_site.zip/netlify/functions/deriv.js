// LTP Prosperity - proxy seguro para a API nova da Deriv.
// Faz a troca do código OAuth por token (que não pode ser feita no browser)
// e as chamadas REST de contas e OTP.
const CLIENT_ID = process.env.DERIV_CLIENT_ID || "34OZ63DHEWBsSFzWK1f71";
const API = "https://api.derivws.com";

const reply = (status, body) => ({
  statusCode: status,
  headers: { "Content-Type": "application/json", "Cache-Control": "no-store" },
  body: JSON.stringify(body),
});

exports.handler = async (event) => {
  if (event.httpMethod !== "POST") return reply(405, { error: "method_not_allowed" });
  let b;
  try { b = JSON.parse(event.body || "{}"); } catch (e) { return reply(400, { error: "bad_json" }); }

  try {
    if (b.action === "token") {
      if (!b.code || !b.code_verifier || !b.redirect_uri) return reply(400, { error: "missing_fields" });
      const form = new URLSearchParams({
        grant_type: "authorization_code",
        client_id: CLIENT_ID,
        code: String(b.code),
        code_verifier: String(b.code_verifier),
        redirect_uri: String(b.redirect_uri),
      });
      const r = await fetch("https://auth.deriv.com/oauth2/token", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: form,
      });
      const j = await r.json().catch(() => ({}));
      return reply(r.status, j);
    }

    if (typeof b.token !== "string" || b.token.length < 10) return reply(401, { error: "missing_token" });
    const headers = { Authorization: "Bearer " + b.token, "Content-Type": "application/json" };

    if (b.action === "accounts") {
      const r = await fetch(API + "/trading/v1/options/accounts", { headers });
      return reply(r.status, await r.json().catch(() => ({})));
    }

    if (b.action === "otp") {
      if (!/^[A-Za-z0-9_-]+$/.test(String(b.account_id || ""))) return reply(400, { error: "bad_account" });
      const r = await fetch(API + "/trading/v1/options/accounts/" + b.account_id + "/otp", { method: "POST", headers });
      return reply(r.status, await r.json().catch(() => ({})));
    }

    return reply(400, { error: "unknown_action" });
  } catch (e) {
    return reply(502, { error: "upstream_error" });
  }
};
